
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Fornecedor;


public class FornecedorDAO {
    private static final List<Fornecedor> fornecedores = new ArrayList<>(); 
    
    public static void Salvar(Fornecedor fornecedor){
        fornecedores.add(fornecedor);
}
    
    public static List<Fornecedor> listar(){
    return fornecedores;
    
    }
}
